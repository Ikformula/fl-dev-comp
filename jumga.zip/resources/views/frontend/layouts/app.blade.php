<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">
    <link href="{{ asset('py/images/favicon.png')}}" rel="icon" />
    <title>@yield('title') | {{ app_name() }}</title>
    <meta name="description" content="{{ app_name() }} online marketplace with flutterwave for payments">
    <meta name="author" content="Asuquo Bartholomew Ikechukwu">

    <!-- Web Fonts
    ============================================= -->
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i' type='text/css'>

    @stack('before-styles')
    <!-- Stylesheet
    ============================================= -->
    <link rel="stylesheet" type="text/css" href="{{ asset('py/vendor/bootstrap/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('py/vendor/font-awesome/css/all.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('py/vendor/bootstrap-select/css/bootstrap-select.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('py/vendor/currency-flags/css/currency-flags.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('py/vendor/owl.carousel/assets/owl.carousel.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('py/css/stylesheet.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('py/css/color-orange.css')}}" />
    <!-- Toastr -->
    <link rel="stylesheet" href="{{ asset('py/vendor/toastr/toastr.min.css')}}">
    @stack('after-styles')
</head>
<body>

<!-- Preloader -->
<div id="preloader">
    <div data-loader="dual-ring"></div>
</div>
<!-- Preloader End -->

<!-- Document Wrapper
============================================= -->
<div id="main-wrapper">
@include('includes.partials.logged-in-as')
   @include('frontend.includes.header')
    <!-- Content
    ============================================= -->
    <div id="content">
        @yield('content')
    </div>

<!-- Content end -->

<!-- Footer
  ============================================= -->
<footer id="footer">
    <div class="container">
        <div class="row">
           @yield('footer-content')
        </div>
        <div class="footer-copyright pt-3 pt-lg-2 mt-2">
            <div class="row">
                <div class="col-lg">
                    <p class="text-center text-lg-left mb-2 mb-lg-0">Copyright © {{ \Carbon\Carbon::today()->year }} <a href="#">{{ app_name() }}</a>. All Rights Reserved.</p>
                </div>
                <div class="col-lg d-lg-flex align-items-center justify-content-lg-end">
                    <ul class="nav justify-content-center">
                        <li class="nav-item"> <a class="nav-link active" href="https://gitshowcase.com/ikformula">Developed By Iyke</a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer end -->

</div>
<!-- Document Wrapper end -->

<!-- Back to Top
============================================= -->
<a id="back-to-top" data-toggle="tooltip" title="Back to Top" href="javascript:void(0)"><i class="fa fa-chevron-up"></i></a>

<!-- Script -->
@stack('before-scripts')
<script src="{{ asset('py/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{ asset('py/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{ asset('py/vendor/bootstrap-select/js/bootstrap-select.min.js')}}"></script>
<script src="{{ asset('py/vendor/owl.carousel/owl.carousel.min.js')}}"></script>
<script src="{{ asset('py/js/theme.js')}}"></script>
<!-- Toastr -->
<script src="{{ asset('py/vendor/toastr/toastr.min.js')}}"></script>
@include('includes.partials.messages')
@stack('after-scripts')
</body>

</html>
