@extends('frontend.layouts.app')

@section('title', 'Orders')

@section('content')
    <div class="container my-4">
        <div class="row my-2">
            <div class="col col-sm-12 align-self-center">
                <div class="bg-light shadow-sm rounded p-0 mb-4 text-center">
                    @if($orders->count())
                        <table class="table">
                            <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Product</th>
                                <th>Amount Paid</th>
                                <th>Delivery Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>

                            <tbody>
                            @foreach($orders as $order)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $order->product()->title }}</td>
                                    <td>{{ number_format($order->payment()->amount) }} {{ $order->payment()->curency }}</td>
                                    <td>{{ $order->delivered_at }}</td>
                                    <td><a href="{{ route('frontend.product.show', $product) }}" class="btn btn-sm btn-info">Edit</a> </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <p class="my-5 p-5">No orders</p>
                    @endif

                </div><!--card-->
            </div><!--col-->
        </div>
    </div>
@endsection
