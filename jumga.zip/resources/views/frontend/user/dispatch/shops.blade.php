@extends('frontend.layouts.app')

@section('title', 'Assigned Stores')

@section('content')
    <div class="container my-4">
        <div class="row my-2">
        </div>
    </div>
@endsection
