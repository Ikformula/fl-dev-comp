@extends('frontend.layouts.app')

@section('title', $shop->name)

@section('content')
    <div class="container my-4">
        <div class="row my-2">
            @forelse($shop->listedProducts() as $product)
                <div class="col-md-4 d-flex align-items-stretch">
                    <div class="card shadow-sm border-0 mb-4"><a
                            href="{{ route('frontend.shop_front.show.product', ['slug' => $shop->slug, 'product_id' => $product->id]) }}"><img
                                class="card-img-top" src="{{ productImagePath() }}/{{ $product->image_path }}"
                                alt="{{ $product->title }} image"></a>
                        <div class="card-body">
                            <h4 class="title-blog text-5"><a
                                    href="{{ route('frontend.shop_front.show.product', ['slug' => $shop->slug, 'product_id' => $product->id]) }}">{{ $product->title }}</a>
                            </h4>
                            <p>{{ $product->description }}</p>
                        </div>
                        <div class="card-footer">
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="price text-success"><h5 class="mt-4">{{ $product->price() }}</h5></div>
                                <a href="{{ route('frontend.shop_front.show.product', ['slug' => $shop->slug, 'product_id' => $product->id]) }}" class="btn btn-primary mt-3"><i class="fas fa-shopping-cart"></i> Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>

            @empty
                <p>This store has no products listed yet</p>
            @endforelse
        </div>


    </div>


@endsection

@section('footer-content')
    <div class="col-lg">
        <h5>{{ $shop->name }}</h5>
       <div>by {{ $shop->owner()->full_name }} {{ $shop->owner()->email }}</div>

        <p>{{ $shop->description }}</p>
    </div>

@endsection
