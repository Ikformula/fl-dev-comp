@extends('frontend.layouts.app')

@section('title', $product->title)

@section('content')
    <div class="container my-4">
        <div class="row my-2">
            <div class="col-md-4">
                <div class="card shadow-sm border-0 mb-4"><a
                        href="#"><img
                            class="card-img-top" src="{{ productImagePath() }}/{{ $product->image_path }}"
                            alt="{{ $product->title }} image"></a>
                    <div class="card-body">
                        <h4 class="title-blog text-5"><a
                                href="#">{{ $product->title }}</a>
                        </h4>
                        <p>{{ $product->description }}</p>
                    </div>
                    <div class="card-footer">
                        <div class="buy d-flex justify-content-between align-items-center">
                            <div class="price text-success"><h5 class="mt-4">{{ $product->price() }}</h5></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                    <form action="" method="post">

                        <div class="row">
                            <div class="col-md-6">
                                <strong>Product Delivery Details</strong>
                                <div class="form-group">
                                    <label for="quantity">Quantity</label>
                                    <input type="number" name="quantity" min="1" id="quantity" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <select class="custom-select" id="country" name="country" required>
                                        @include('includes.partials.countries-options')
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="state">State</label>
                                    <input type="text" name="state" id="state" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" name="address" id="address" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-6">


                                <strong>Contact Information</strong>
                                <div class="form-group">
                                    <label for="first_name">First Name</label>
                                    <input type="text" name="first_name" id="first_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" name="last_name" id="last_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" id="email" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone Number</label>
                                    <input type="text" name="phone" id="phone" class="form-control" required>
                                </div>
                            </div>

                        </div>
                        <div class="row p-2">
                            <div class="col-sm-12">
                                <h6>Payment Summary</h6>
                                <span><strong>Delivery Fee Per Unit:</strong> {{ $product->currency }} {{ $product->delivery_fee }}</span> <span><strong>Total:</strong> {{ $product->currency }} <span class="text-4" id="total">{{ $product->price + $product->delivery_fee }}</span></span>

                                <button type="submit" class="btn btn-primary btn-block">Proceed to Payment</button>
                            </div>
                        </div>


                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('footer-content')
    <div class="col-lg">
        <h5>{{ $shop->name }}</h5>
        <div>by {{ $shop->owner()->full_name }} {{ $shop->owner()->email }}</div>

        <p>{{ $shop->description }}</p>
    </div>

@endsection
