<!doctype html>
<html>
<head>
    <title>Make Payment</title>
</head>
<body>

<form>
    <script src="https://checkout.flutterwave.com/v3.js"></script>
    <button type="button" onClick="makePayment()">Pay Now</button>
</form>
<script>
    function makePayment() {
        FlutterwaveCheckout({
            public_key: "{{ $_ENV['FLUTTERWAVE_PK'] }}",
            tx_ref: "{{ $payment->transaction_ref }}",
            amount: {{ $payment->amount }},
            currency: "{{ $payment->currency }}",
            country: "{{ $payment->country }}",
            payment_options: "card, mobilemoneyghana, ussd",
            redirect_url: // specified redirect URL
                "{{ route('frontend.verify.payment') }}?trx_ref={{ $payment->transaction_ref }}",
            meta: {
                consumer_mac: "{{ md5($payment->customer_email) }}",
            },
            customer: {
                email: "{{ $payment->customer_email }}",
                name: "{{ $payment->name }}",
            },
            @if(!is_null($splits))
{{--            for splitting payments for products --}}
            subaccounts: [
                {
                    id: "{{ $splits[1]['id'] }}",
                    transaction_charge_type: "percentage",
                    transaction_charge: "{{ $splits[1]['percentage'] }}"
                },

                {
                    id: "{{ $splits[2]['id'] }}",
                    transaction_charge_type: "percentage",
                    transaction_charge: "{{ $splits[2]['percentage'] }}"
                }

            ],
            @endif
            callback: function (data) {
                console.log(data);
            },
            onclose: function () {
                // close modal
            },
            customizations: {
                title: "{{ app_name() }}",
                logo: "{{ asset('py/images/logo.png')}}",
            },
        });
    }

        makePayment();

</script>
</body>
</html>
