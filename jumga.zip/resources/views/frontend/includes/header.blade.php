<!-- Header
    ============================================= -->
<header id="header">
    <div class="container">
        <div class="header-row">
            <div class="header-column justify-content-start">
                <!-- Logo
                ============================= -->
                <div class="logo"> <a class="d-flex" href="{{ route('frontend.index') }}" title="{{ app_name() }}"><h4>{{ app_name() }}  <i class="fa fa-shopping-cart"></i></h4> </a> </div>
                <!-- Logo end -->
                <!-- Collapse Button
                ============================== -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#header-nav"> <span></span> <span></span> <span></span> </button>
                <!-- Collapse Button end -->

                <!-- Primary Navigation
                ============================== -->
                <nav class="primary-menu navbar navbar-expand-lg">
                    <div id="header-nav" class="collapse navbar-collapse">
                        <ul class="navbar-nav mr-auto">
{{--                            <li><a href="landing-page-send.html">Send</a></li>--}}
{{--                            <li class="active"><a href="landing-page-receive.html">Receive</a></li>--}}
{{--                            <li><a href="about-us.html">About Us</a></li>--}}
{{--                            <li><a href="fees.html">Fees</a></li>--}}
{{--                            <li><a href="{{ route('frontend.contact') }}">Help</a></li>--}}

                        </ul>
                    </div>
                </nav>
                <!-- Primary Navigation end -->
            </div>
            <div class="header-column justify-content-end">

                <nav class="login-signup navbar navbar-expand">
                    <ul class="navbar-nav">
                        @auth
                            <li class="dropdown language"> <a class="dropdown-toggle" href="#">{{ $logged_in_user->first_name }}</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="{{route('frontend.auth.logout')}}">Log Out</a></li>
                                </ul>
                            </li>
                            <li class="align-items-center h-auto ml-sm-3"><a class="btn btn-primary d-none d-sm-block" href="{{route('frontend.user.dashboard')}}">Dashboard</a></li>
                        @endauth

                            @guest
                        <li><a href="{{route('frontend.auth.login')}}">Login</a> </li>
                        <li class="align-items-center h-auto ml-sm-3"><a class="btn btn-primary d-none d-sm-block" href="{{route('frontend.auth.register')}}">Get Your Own Store</a></li>
                            @endguest
                    </ul>
                </nav>
                <!-- Login & Signup Link end -->
            </div>
        </div>
    </div>
</header>
<!-- Header End -->
