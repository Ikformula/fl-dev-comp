@readonly
    <div class="alert alert-info read-only">
        The Application is currently in read only mode. All requests other than GET are disabled.
    </div>
@endreadonly
