<option disabled selected>Select Country</option>
<option value="NG">Nigeria</option>
<option value="GH">Ghana</option>
<option value="KE">Kenya</option>
<option value="UK">UK</option>
