<script>
    function makePayment() {
        FlutterwaveCheckout({
            public_key: "{{ $_ENV['FLUTTERWAVE_PK'] }}",
            tx_ref: "{{ $payment_data['transaction_ref'] }}",
            amount: {{ $payment_data['amount'] }},
            currency: "{{ $payment_data['currency'] }}",
            country: "{{ $payment_data['country'] }}",
            payment_options: "card, mobilemoneyghana, ussd",
            redirect_url: // specified redirect URL
                "https://callbacks.piedpiper.com/flutterwave.aspx?ismobile=34",
            meta: {
                consumer_id: {{ $payment_data['consumer_id'] }},
                consumer_mac: "{{ $payment_data['consumer_mac'] }}",
            },
            customer: {
                email: "{{ $payment_data['email'] }}",
                name: "{{ $payment_data['name'] }}",
            },
            callback: function (data) {
                console.log(data);
            },
            onclose: function() {
                // close modal
            },
            customizations: {
                title: "{{ app_name() }}",
                description: "{{ $payment_data['description'] }}",
                logo: "https://assets.piedpiper.com/logo.png",
            },
        });
    }
</script>
