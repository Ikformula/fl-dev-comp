<footer class="app-footer">
    <div>
        <strong>@lang('labels.general.copyright') &copy; {{ date('Y') }}
            <a href="http://laravel-boilerplate.com">
                @lang('strings.backend.general.boilerplate_link')
            </a>
        </strong> @lang('strings.backend.general.all_rights_reserved')
    </div>

    <div class="ml-auto">Theme by <a href="http://coreui.io">CoreUI</a></div>
</footer>
