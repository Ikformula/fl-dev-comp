@extends('backend.layouts.app')

@section('title', app_name() . ' | ' . __('strings.backend.dashboard.title'))

@section('content')
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong>@lang('strings.backend.dashboard.welcome') {{ $logged_in_user->name }}!</strong>
                </div><!--card-header-->
                <div class="card-body">
                   <h4>Pending Store Approvals</h4>
                    @if($shops->count())
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Shop Name</th>
                                <th>Country</th>
                                <th>Assign Rider</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                        <tbody>
                    @foreach($shops as $shop)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $shop->name }}</td>
                            <td>{{ $shop->country }}</td>
                            <form action="{{ route('admin.assign.rider') }}" method="post">
                                @csrf
                                <input type="hidden" name="shop_id" value="{{ $shop->id }}">
                            <td>

                                   <select name="rider_id" class="form-control">
                                       @foreach($riders as $rider)
                                           <option value="{{ $rider->id }}">{{ $rider->full_name }}</option>
                                       @endforeach
                                   </select>

                            </td>
                            <td><button type="submit" class="btn btn-primary">Submit</button></td>
                            </form>
                        </tr>

                    @endforeach
                        </tbody>
                        </table>
                    @endif


                </div><!--card-body-->
            </div><!--card-->
        </div><!--col-->
    </div><!--row-->
@endsection
