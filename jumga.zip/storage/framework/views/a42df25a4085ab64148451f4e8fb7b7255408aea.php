<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <div class="row my-2">
            <div class="col col-sm-12 align-self-center">
                <div class="bg-light shadow-sm rounded p-0 mb-4 text-center">
                    <?php if($orders->count()): ?>
                        <table class="table">
                            <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Product</th>
                                <th>Amount Paid</th>
                                <th>Delivery Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($order->product()->title); ?></td>
                                    <td><?php echo e(number_format($order->payment()->amount)); ?> <?php echo e($order->payment()->curency); ?></td>
                                    <td><?php echo e($order->delivered_at); ?></td>
                                    <td><a href="<?php echo e(route('frontend.product.show', $product)); ?>" class="btn btn-sm btn-info">Edit</a> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="my-5 p-5">No orders</p>
                    <?php endif; ?>

                </div><!--card-->
            </div><!--col-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/user/shop/orders.blade.php ENDPATH**/ ?>