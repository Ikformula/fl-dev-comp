<option disabled selected>Select Country</option>
<option value="NG">Nigeria</option>
<option value="GH">Ghana</option>
<option value="KE">Kenya</option>
<option value="UK">UK</option>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/includes/partials/countries-options.blade.php ENDPATH**/ ?>