<?php $__env->startSection('title', app_name() . ' | ' . __('strings.backend.dashboard.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong><?php echo app('translator')->get('strings.backend.dashboard.welcome'); ?> <?php echo e($logged_in_user->name); ?>!</strong>
                </div><!--card-header-->
                <div class="card-body">
                   <h4>Pending Store Approvals</h4>
                    <?php if($shops->count()): ?>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Shop Name</th>
                                <th>Country</th>
                                <th>Assign Rider</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                        <tbody>
                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($shop->name); ?></td>
                            <td><?php echo e($shop->country); ?></td>
                            <form action="<?php echo e(route('admin.assign.rider')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="shop_id" value="<?php echo e($shop->id); ?>">
                            <td>

                                   <select name="rider_id" class="form-control">
                                       <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option value="<?php echo e($rider->id); ?>"><?php echo e($rider->full_name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>

                            </td>
                            <td><button type="submit" class="btn btn-primary">Submit</button></td>
                            </form>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    <?php endif; ?>


                </div><!--card-body-->
            </div><!--card-->
        </div><!--col-->
    </div><!--row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>