<!-- Header
    ============================================= -->
<header id="header">
    <div class="container">
        <div class="header-row">
            <div class="header-column justify-content-start">
                <!-- Logo
                ============================= -->
                <div class="logo"> <a class="d-flex" href="<?php echo e(route('frontend.index')); ?>" title="<?php echo e(app_name()); ?>"><h4><?php echo e(app_name()); ?>  <i class="fa fa-shopping-cart"></i></h4> </a> </div>
                <!-- Logo end -->
                <!-- Collapse Button
                ============================== -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#header-nav"> <span></span> <span></span> <span></span> </button>
                <!-- Collapse Button end -->

                <!-- Primary Navigation
                ============================== -->
                <nav class="primary-menu navbar navbar-expand-lg">
                    <div id="header-nav" class="collapse navbar-collapse">
                        <ul class="navbar-nav mr-auto">






                        </ul>
                    </div>
                </nav>
                <!-- Primary Navigation end -->
            </div>
            <div class="header-column justify-content-end">

                <nav class="login-signup navbar navbar-expand">
                    <ul class="navbar-nav">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="dropdown language"> <a class="dropdown-toggle" href="#"><?php echo e($logged_in_user->first_name); ?></a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo e(route('frontend.auth.logout')); ?>">Log Out</a></li>
                                </ul>
                            </li>
                            <li class="align-items-center h-auto ml-sm-3"><a class="btn btn-primary d-none d-sm-block" href="<?php echo e(route('frontend.user.dashboard')); ?>">Dashboard</a></li>
                        <?php endif; ?>

                            <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('frontend.auth.login')); ?>">Login</a> </li>
                        <li class="align-items-center h-auto ml-sm-3"><a class="btn btn-primary d-none d-sm-block" href="<?php echo e(route('frontend.auth.register')); ?>">Get Your Own Store</a></li>
                            <?php endif; ?>
                    </ul>
                </nav>
                <!-- Login & Signup Link end -->
            </div>
        </div>
    </div>
</header>
<!-- Header End -->
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>