<script>
<?php if($errors->any()): ?>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error('<?php echo $error; ?>')
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php elseif(session()->get('flash_success')): ?>

        <?php if(is_array(json_decode(session()->get('flash_success'), true))): ?>
            toastr.success('<?php echo implode('', session()->get('flash_success')->all(':message<br/>')); ?>')
        <?php else: ?>
        toastr.success('<?php echo session()->get('flash_success'); ?>')
        <?php endif; ?>

<?php elseif(session()->get('flash_warning')): ?>

        <?php if(is_array(json_decode(session()->get('flash_warning'), true))): ?>
        toastr.warning('<?php echo implode('', session()->get('flash_warning')->all(':message<br/>')); ?>')
        <?php else: ?>
        toastr.warning('<?php echo session()->get('flash_warning'); ?>')
        <?php endif; ?>

<?php elseif(session()->get('flash_info')): ?>

        <?php if(is_array(json_decode(session()->get('flash_info'), true))): ?>
        toastr.info('<?php echo implode('', session()->get('flash_info')->all(':message<br/>')); ?>')
        <?php else: ?>
        toastr.info('<?php echo session()->get('flash_info'); ?>')
        <?php endif; ?>

<?php elseif(session()->get('flash_danger')): ?>

        <?php if(is_array(json_decode(session()->get('flash_danger'), true))): ?>
        toastr.error('<?php echo implode('', session()->get('flash_danger')->all(':message<br/>')); ?>')
        <?php else: ?>
        toastr.error('<?php echo session()->get('flash_danger'); ?>')
        <?php endif; ?>

<?php elseif(session()->get('flash_message')): ?>

        <?php if(is_array(json_decode(session()->get('flash_message'), true))): ?>
        toastr.info('<?php echo implode('', session()->get('flash_message')->all(':message<br/>')); ?>')
        <?php else: ?>
        toastr.info('<?php echo session()->get('flash_message'); ?>')
        <?php endif; ?>

<?php endif; ?>

</script>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/includes/partials/messages.blade.php ENDPATH**/ ?>