<?php $__env->startSection('title', $product->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <div class="row my-2">
            <div class="col-md-4">
                <div class="card shadow-sm border-0 mb-4"><a
                        href="#"><img
                            class="card-img-top" src="<?php echo e(productImagePath()); ?>/<?php echo e($product->image_path); ?>"
                            alt="<?php echo e($product->title); ?> image"></a>
                    <div class="card-body">
                        <h4 class="title-blog text-5"><a
                                href="#"><?php echo e($product->title); ?></a>
                        </h4>
                        <p><?php echo e($product->description); ?></p>
                    </div>
                    <div class="card-footer">
                        <div class="buy d-flex justify-content-between align-items-center">
                            <div class="price text-success"><h5 class="mt-4"><?php echo e($product->price()); ?></h5></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                    <form action="" method="post">

                        <div class="row">
                            <div class="col-md-6">
                                <strong>Product Delivery Details</strong>
                                <div class="form-group">
                                    <label for="quantity">Quantity</label>
                                    <input type="number" name="quantity" min="1" id="quantity" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <select class="custom-select" id="country" name="country" required>
                                        <?php echo $__env->make('includes.partials.countries-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="state">State</label>
                                    <input type="text" name="state" id="state" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" name="address" id="address" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-6">


                                <strong>Contact Information</strong>
                                <div class="form-group">
                                    <label for="first_name">First Name</label>
                                    <input type="text" name="first_name" id="first_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" name="last_name" id="last_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" id="email" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone Number</label>
                                    <input type="text" name="phone" id="phone" class="form-control" required>
                                </div>
                            </div>

                        </div>
                        <div class="row p-2">
                            <div class="col-sm-12">
                                <h6>Payment Summary</h6>
                                <span><strong>Delivery Fee Per Unit:</strong> <?php echo e($product->currency); ?> <?php echo e($product->delivery_fee); ?></span> <span><strong>Total:</strong> <?php echo e($product->currency); ?> <span class="text-4" id="total"><?php echo e($product->price + $product->delivery_fee); ?></span></span>

                                <button type="submit" class="btn btn-primary btn-block">Proceed to Payment</button>
                            </div>
                        </div>


                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>
    <div class="col-lg">
        <h5><?php echo e($shop->name); ?></h5>
        <div>by <?php echo e($shop->owner()->full_name); ?> <?php echo e($shop->owner()->email); ?></div>

        <p><?php echo e($shop->description); ?></p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/shop_front/show-product.blade.php ENDPATH**/ ?>