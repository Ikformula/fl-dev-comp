<?php $__env->startSection('title', $shop->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <div class="row my-2">
            <?php $__empty_1 = true; $__currentLoopData = $shop->listedProducts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 d-flex align-items-stretch">
                    <div class="card shadow-sm border-0 mb-4"><a
                            href="<?php echo e(route('frontend.shop_front.show.product', ['slug' => $shop->slug, 'product_id' => $product->id])); ?>"><img
                                class="card-img-top" src="<?php echo e(productImagePath()); ?>/<?php echo e($product->image_path); ?>"
                                alt="<?php echo e($product->title); ?> image"></a>
                        <div class="card-body">
                            <h4 class="title-blog text-5"><a
                                    href="<?php echo e(route('frontend.shop_front.show.product', ['slug' => $shop->slug, 'product_id' => $product->id])); ?>"><?php echo e($product->title); ?></a>
                            </h4>
                            <p><?php echo e($product->description); ?></p>
                        </div>
                        <div class="card-footer">
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="price text-success"><h5 class="mt-4"><?php echo e($product->price()); ?></h5></div>
                                <a href="<?php echo e(route('frontend.shop_front.show.product', ['slug' => $shop->slug, 'product_id' => $product->id])); ?>" class="btn btn-primary mt-3"><i class="fas fa-shopping-cart"></i> Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>This store has no products listed yet</p>
            <?php endif; ?>
        </div>


    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>
    <div class="col-lg">
        <h5><?php echo e($shop->name); ?></h5>
       <div>by <?php echo e($shop->owner()->full_name); ?> <?php echo e($shop->owner()->email); ?></div>

        <p><?php echo e($shop->description); ?></p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/shop_front/products.blade.php ENDPATH**/ ?>