<?php $__env->startSection('title', 'My Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <div class="row my-2">
            <div class="col-6">
                <h4 class=" align-middle">
                    Products
                </h4>
            </div>
            <div class="col-6">
                    <button type="button" data-toggle="modal" data-target="#addProduct" class="btn btn-primary float-right">+ Add a Product</button>
            </div>
        </div>
                <div class="row">
                    <div class="col col-sm-12 align-self-center">

                <div class="bg-light shadow-sm rounded p-0 mb-4 text-center">
                    <?php if($products->count()): ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Title</th>
                            <th>Price</th>

                            <th>Actions</th>
                        </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($product->title); ?></td>
                                    <td><?php echo e($product->price()); ?></td>

                                    <td><a href="<?php echo e(route('frontend.product.show', $product)); ?>" class="btn btn-sm btn-info">Edit</a> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                        <p class="my-5">No products added yet</p>
                    <?php endif; ?>

                </div><!--card-->
            </div><!--col-->
        </div><!--row-->
    </div>

    <div class="my-5"></div>
    <div class="modal fade" tabindex="-1" id="addProduct">
        <div class="modal-dialog" role="document">
            <div class="modal-content px-3">



                <div class="modal-body p-3 p-sm-4 mb-4">
                    <h3 class="text-5 font-weight-400 mb-3">Product Details</h3>

                    <form action="<?php echo e(route('frontend.product.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="shop_id" value="<?php echo e($logged_in_user->shop()->id); ?>">

                        <div class="form-group">
                            <label for="title">Product Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>

                        <div class="form-group">
                            <label for="price">Price (<?php echo e($_ENV['DEFAULT_CURRENCY']); ?>)</label>
                            <input type="number" min="1" class="form-control" onkeyup="addFee(this.value)" id="price" name="price" required>
                        </div>

                        <div class="form-group">
                            <label for="delivery_fee">Delivery Fee (<?php echo e($_ENV['DEFAULT_CURRENCY']); ?>)</label>
                            <input type="number" min="1" class="form-control" id="delivery_fee" name="delivery_fee" required>
                            <small class="text-info">Please note that <?php echo e($_ENV['DELIVERY_PERCENT']); ?>% (<span id="delivery-charge"></span> <?php echo e($_ENV['DEFAULT_CURRENCY']); ?>) of your product price will be added to the delivery fee</small>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" class="form-control" id="description" name="description" required>
                        </div>

                        <div class="form-group">
                            <label for="photo">Product Image</label>
                            <input type="file" class="form-control" id="photo" accept="image/*" name="photo" required>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Submit</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        function addFee(price){
            let charge = Math.round(<?php echo e($_ENV['DELIVERY_PERCENT'] / 100); ?> * price);
            $('#delivery-charge').html(charge);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/user/shop/products.blade.php ENDPATH**/ ?>