<?php if($user->isConfirmed()): ?>
    <?php if($user->id !== 1 && $user->id !== auth()->id()): ?>
        <a href="<?php echo e(route( 'admin.auth.user.unconfirm', $user)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.backend.access.users.unconfirm'); ?>" name="confirm_item">
            <span class="badge badge-success" style="cursor:pointer"><?php echo app('translator')->get('labels.general.yes'); ?></span>
        </a>
    <?php else: ?>
        <span class="badge badge-success"><?php echo app('translator')->get('labels.general.yes'); ?></span>
    <?php endif; ?>
<?php else: ?>
    <a href="<?php echo e(route('admin.auth.user.confirm', $user)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.backend.access.users.confirm'); ?>" name="confirm_item">
        <span class="badge badge-danger" style="cursor:pointer"><?php echo app('translator')->get('labels.general.no'); ?></span>
    </a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/backend/auth/user/includes/confirm.blade.php ENDPATH**/ ?>