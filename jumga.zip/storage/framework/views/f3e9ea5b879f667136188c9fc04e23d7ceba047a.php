<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">
    <link href="<?php echo e(asset('py/images/favicon.png')); ?>" rel="icon" />
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(app_name()); ?></title>
    <meta name="description" content="<?php echo e(app_name()); ?> online marketplace with flutterwave for payments">
    <meta name="author" content="Asuquo Bartholomew Ikechukwu">

    <!-- Web Fonts
    ============================================= -->
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i' type='text/css'>

    <?php echo $__env->yieldPushContent('before-styles'); ?>
    <!-- Stylesheet
    ============================================= -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/vendor/bootstrap/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/vendor/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/vendor/bootstrap-select/css/bootstrap-select.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/vendor/currency-flags/css/currency-flags.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/css/stylesheet.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('py/css/color-orange.css')); ?>" />
    <!-- Toastr -->
    <link rel="stylesheet" href="<?php echo e(asset('py/vendor/toastr/toastr.min.css')); ?>">
    <?php echo $__env->yieldPushContent('after-styles'); ?>
</head>
<body>

<!-- Preloader -->
<div id="preloader">
    <div data-loader="dual-ring"></div>
</div>
<!-- Preloader End -->

<!-- Document Wrapper
============================================= -->
<div id="main-wrapper">
<?php echo $__env->make('includes.partials.logged-in-as', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Content
    ============================================= -->
    <div id="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

<!-- Content end -->

<!-- Footer
  ============================================= -->
<footer id="footer">
    <div class="container">
        <div class="row">
           <?php echo $__env->yieldContent('footer-content'); ?>
        </div>
        <div class="footer-copyright pt-3 pt-lg-2 mt-2">
            <div class="row">
                <div class="col-lg">
                    <p class="text-center text-lg-left mb-2 mb-lg-0">Copyright © <?php echo e(\Carbon\Carbon::today()->year); ?> <a href="#"><?php echo e(app_name()); ?></a>. All Rights Reserved.</p>
                </div>
                <div class="col-lg d-lg-flex align-items-center justify-content-lg-end">
                    <ul class="nav justify-content-center">
                        <li class="nav-item"> <a class="nav-link active" href="#">Security</a></li>
                        <li class="nav-item"> <a class="nav-link" href="#">Terms</a></li>
                        <li class="nav-item"> <a class="nav-link" href="#">Privacy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer end -->

</div>
<!-- Document Wrapper end -->

<!-- Back to Top
============================================= -->
<a id="back-to-top" data-toggle="tooltip" title="Back to Top" href="javascript:void(0)"><i class="fa fa-chevron-up"></i></a>

<!-- Script -->
<?php echo $__env->yieldPushContent('before-scripts'); ?>
<script src="<?php echo e(asset('py/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('py/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('py/vendor/bootstrap-select/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('py/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('py/js/theme.js')); ?>"></script>
<!-- Toastr -->
<script src="<?php echo e(asset('py/vendor/toastr/toastr.min.js')); ?>"></script>
<?php echo $__env->make('includes.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('after-scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>