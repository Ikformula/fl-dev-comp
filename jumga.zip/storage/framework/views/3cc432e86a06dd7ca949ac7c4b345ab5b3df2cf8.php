<?php if(config('services.bitbucket.active')): ?>
    <a href='<?php echo e(route('frontend.auth.social.login', 'bitbucket')); ?>' class='btn btn-sm btn-outline-info m-1'><i class='fab fa-bitbucket'></i> <?php echo app('translator')->get('labels.frontend.auth.login_with', ['social_media' => 'BitBucket']); ?></a>
<?php endif; ?>

<?php if(config('services.facebook.active')): ?>
    <a href='<?php echo e(route('frontend.auth.social.login', 'facebook')); ?>' class='btn btn-sm btn-outline-info m-1'><i class='fab fa-facebook'></i> <?php echo app('translator')->get('labels.frontend.auth.login_with', ['social_media' => 'Facebook']); ?></a>
<?php endif; ?>

<?php if(config('services.google.active')): ?>
    <a href='<?php echo e(route('frontend.auth.social.login', 'google')); ?>' class='btn btn-sm btn-outline-info m-1'><i class='fab fa-google'></i> <?php echo app('translator')->get('labels.frontend.auth.login_with', ['social_media' => 'Google']); ?></a>
<?php endif; ?>

<?php if(config('services.github.active')): ?>
    <a href='<?php echo e(route('frontend.auth.social.login', 'github')); ?>' class='btn btn-sm btn-outline-info m-1'><i class='fab fa-github'></i> <?php echo app('translator')->get('labels.frontend.auth.login_with', ['social_media' => 'Github']); ?></a>
<?php endif; ?>

<?php if(config('services.linkedin.active')): ?>
    <a href='<?php echo e(route('frontend.auth.social.login', 'linkedin')); ?>' class='btn btn-sm btn-outline-info m-1'><i class='fab fa-linkedin'></i> <?php echo app('translator')->get('labels.frontend.auth.login_with', ['social_media' => 'LinkedIn']); ?></a>
<?php endif; ?>

<?php if(config('services.twitter.active')): ?>
    <a href='<?php echo e(route('frontend.auth.social.login', 'twitter')); ?>' class='btn btn-sm btn-outline-info m-1'><i class='fab fa-twitter'></i> <?php echo app('translator')->get('labels.frontend.auth.login_with', ['social_media' => 'Twitter']); ?></a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/auth/includes/socialite.blade.php ENDPATH**/ ?>