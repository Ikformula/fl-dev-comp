<?php $__env->startSection('title',  __('labels.frontend.auth.register_box_title')); ?>

<?php $__env->startSection('content'); ?>

        <div class="container">
    <div class="row justify-content-center align-items-center my-5">
        <div class="col col-sm-8 align-self-center">
            <div class="card bg-light shadow-sm rounded">
                <div class="card-header">
                    <strong>
                        <?php echo app('translator')->get('labels.frontend.auth.register_box_title'); ?>
                    </strong>
                </div><!--card-header-->

                <div class="card-body">
                    <?php echo e(html()->form('POST', route('frontend.auth.register.post'))->open()); ?>

                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <?php echo e(html()->label(__('validation.attributes.frontend.first_name'))->for('first_name')); ?>


                                    <?php echo e(html()->text('first_name')
                                        ->class('form-control')
                                        ->placeholder(__('validation.attributes.frontend.first_name'))
                                        ->attribute('maxlength', 191)
                                        ->required()); ?>

                                </div><!--col-->
                            </div><!--row-->

                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <?php echo e(html()->label(__('validation.attributes.frontend.last_name'))->for('last_name')); ?>


                                    <?php echo e(html()->text('last_name')
                                        ->class('form-control')
                                        ->placeholder(__('validation.attributes.frontend.last_name'))
                                        ->attribute('maxlength', 191)
                                        ->required()); ?>

                                </div><!--form-group-->
                            </div><!--col-->
                        </div><!--row-->

                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <?php echo e(html()->label(__('validation.attributes.frontend.email'))->for('email')); ?>


                                    <?php echo e(html()->email('email')
                                        ->class('form-control')
                                        ->placeholder(__('validation.attributes.frontend.email'))
                                        ->attribute('maxlength', 191)
                                        ->required()); ?>

                                </div><!--form-group-->
                            </div><!--col-->

                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <?php echo e(html()->label('Phone Number')->for('phone')); ?>


                                    <?php echo e(html()->text('phone')
                                        ->class('form-control')
                                        ->attribute('maxlength', 191)
                                        ->required()); ?>

                                </div><!--form-group-->
                            </div><!--col-->
                        </div><!--row-->

                        <div class="row">
                                <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <?php echo e(html()->label(__('validation.attributes.frontend.password'))->for('password')); ?>


                                    <?php echo e(html()->password('password')
                                        ->class('form-control')
                                        ->placeholder(__('validation.attributes.frontend.password'))
                                        ->attribute('maxlength', 191)
                                        ->attribute('minlength', 8)
                                        ->required()); ?>

                                    <small>Minimum of 8 characters</small>
                                </div><!--form-group-->
                            </div><!--col-->

                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <?php echo e(html()->label(__('validation.attributes.frontend.password_confirmation'))->for('password_confirmation')); ?>


                                    <?php echo e(html()->password('password_confirmation')
                                        ->class('form-control')
                                        ->placeholder(__('validation.attributes.frontend.password_confirmation'))
                                        ->required()); ?>

                                </div><!--form-group-->
                            </div><!--col-->
                        </div><!--row-->

                        <?php if(config('access.captcha.registration')): ?>
                            <div class="row">
                                <div class="col">
                                    <?php echo app('captcha')->render(); ?>
                                    <?php echo e(html()->hidden('captcha_status', 'true')); ?>

                                </div><!--col-->
                            </div><!--row-->
                        <?php endif; ?>
                    <div class="form-group">
                        <label for="duty">Registering as</label>
                        <select id="duty" class="form-control" name="duty"  required>
                            <option value="shop">Shop Owner</option>
                            <option value="rider">Dispatch Rider</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="inputCountry">Country you're resident in</label>
                        <select class="custom-select" onchange="getBanks(this.value)" id="inputCountry" name="country" required>
                            <?php echo $__env->make('includes.partials.countries-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </select>
                    </div>

                    <strong>Bank Account Info. For Receiving Payments</strong>
                    <div class="form-group">
                        <label for="account_bank">Bank Name</label>
                        <select id="account_bank" class="form-control" name="account_bank"  required></select>
                        <small id="banks-status" class="text-info">Select your country first</small>
                    </div>

                    <div class="form-group">
                        <label for="account_number">Account Number</label>
                        <input type="number" id="account_number" class="form-control" name="account_number" readonly value="06900000<?php echo e(rand(21, 41)); ?>" maxlength="191" required>
                    </div>

                    <div class="form-group">
                        <label for="account_number">Account Name</label>
                        <input type="text" value="" id="account_name" class="form-control" name="account_name" required>
                    </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group mb-0 clearfix">
                                    <?php echo e(form_submit(__('labels.frontend.auth.register_button'))); ?>

                                </div><!--form-group-->
                            </div><!--col-->
                        </div><!--row-->
                    <?php echo e(html()->form()->close()); ?>


                    <div class="row">
                        <div class="col">
                            <div class="text-center">
                                <?php echo $__env->make('frontend.auth.includes.socialite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div><!--/ .col -->
                    </div><!-- / .row -->
                </div><!-- card-body -->
            </div><!-- card -->
        </div><!-- col-md-8 -->
    </div><!-- row -->
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <?php if(config('access.captcha.registration')): ?>
        <?php echo app('captcha')->renderFooterJS(); ?>
    <?php endif; ?>
    <script>
        function getBanks(country){
            $('#banks-status').html('Loading Banks...');
            fetch('<?php echo e($_ENV['APP_URL']); ?>/api/banks/' + country).then(function (response) {
                // The API call was successful!
                return response.text();
            }).then(function (ohtml) {
                // This is the HTML from our response as a text string
                $('#account_bank').html(ohtml)
                //    sort alphabetically
                var sel = $('#account_bank');
                // var selected = sel.val(); // cache selected value, before reordering
                var opts_list = sel.find('option');
                opts_list.sort(function(a, b) { return $(a).text() > $(b).text() ? 1 : -1; });
                sel.html('').append(opts_list);
                // sel.val(selected);
                $('#banks-status').html('');
            }).catch(function (err) {
                // There was an error
                console.warn('Something went wrong.', err);
            });

        }

        function getAccountName(){
            // was getting {"error_id":"ERRNO596940970T1611069079007","message":"Application error. Please contact support","code":"app_error"} when trying to confirm the account name usng the flutterwave resolve endpoint
            let data = {
                account_number: $('#account_number').val(),
                account_bank: $('#account_bank').val()
            }
            let fetchData = {
                method: 'POST',
                body: data
            }
            fetch('<?php echo e(route('verify.account.number')); ?>', fetchData)
                .then(function (response) {
                    return response.json();
                }).then(function (data) {
                var obj = JSON.parse(data);
                if(obj.status == 'success'){
                    $('#account_name').val(obj.data.account_name);
                }

                console.log(data);
            }).catch(function (err) {
                console.warn('Something went wrong.', err);
            });

        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/auth/register.blade.php ENDPATH**/ ?>