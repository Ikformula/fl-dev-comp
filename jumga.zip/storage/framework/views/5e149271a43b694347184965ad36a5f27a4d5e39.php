<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Send Money
        ============================================= -->
    <section class="hero-wrap section">
        <div class="hero-mask opacity-9 bg-primary"></div>
        <div class="hero-bg" style="background-image:url('<?php echo e(asset("py/images/bg/image-5.jpg")); ?>');"></div>
        <div class="hero-content py-2 py-lg-5">
            <div class="container text-center">
                <h2 class="text-14 text-white">Receive Money from Around The World with <?php echo e(app_name()); ?></h2>
                <p class="text-5 text-white mb-4">Quickly and easily start selling online with <?php echo e(app_name()); ?>.<br class="d-none d-lg-block">
                    International payments fully supported.</p>
                <a class="btn btn-light video-btn" href="<?php echo e(route('frontend.auth.register')); ?>"><span class="text-2 mr-3"></span>Sign Up Now</a> </div>
        </div>
    </section>
    <!-- Send Money End -->

    <!-- How it works
    ============================================= -->
    <section class="section bg-white">
        <div class="container">
            <div class="row">
                <div class="col-xl-10 mx-auto">
                    <div class="row">
                        <div class="col-md-5 col-lg-6 text-center my-auto order-2 order-md-1"> <img class="img-fluid shadow" src="<?php echo e(asset('py/images/request-money.png')); ?>" alt=""> </div>
                        <div class="col-md-7 col-lg-6 order-1 order-md-2">
                            <h2 class="text-9"> The simple way to Start Selling Online</h2>
                            <p class="text-3 mb-4">In just 3 easy steps you can start making money selling wares from the comfort of your home</p>
                            <div class="row">
                                <div class="col-12 mb-4">
                                    <div class="featured-box style-3">
                                        <div class="featured-box-icon text-light"><span class="w-100 text-20 font-weight-500">1</span></div>
                                        <h3>Sign Up Your Account</h3>
                                        <p>Become a registered user first, then log in to your account.</p>
                                    </div>
                                </div>
                                <div class="col-12 mb-4">
                                    <div class="featured-box style-3">
                                        <div class="featured-box-icon text-light"><span class="w-100 text-20 font-weight-500">2</span></div>
                                        <h3>Enter Business Details</h3>
                                        <p>Enter your business information and pay for approval.</p>
                                    </div>
                                </div>
                                <div class="col-12 mb-4 mb-sm-0">
                                    <div class="featured-box style-3">
                                        <div class="featured-box-icon text-light"><span class="w-100 text-20 font-weight-500">3</span></div>
                                        <h3>Start Making Money</h3>
                                        <p>Get approved, upload products and get customers buying.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- How it works End -->

    <!-- Why choose us
    ============================================= -->
    <section class="section">
        <div class="container">
            <h2 class="text-9 text-center">Are you ready to join <?php echo e(app_name()); ?>?</h2>
            <p class="text-4 text-center mb-4">Click the button below to start</p>
            <div class="row">
                <div class="col-xl-10 mx-auto">

                    <div class="text-center mt-4"><a href="<?php echo e(route('frontend.auth.register')); ?>" class="btn btn-outline-primary shadow-none text-uppercase">Sign up Now</a></div>
                </div>
            </div>
        </div>
        
    </section>
    <!-- Why choose us End -->


    <!-- Video Modal
    ============================================= -->
    <div class="modal fade" id="videoModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content bg-transparent border-0">
                <button type="button" class="close text-white opacity-10 ml-auto mr-n3 font-weight-400" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="modal-body p-0">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" id="video" allow="autoplay"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Video Modal end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/index.blade.php ENDPATH**/ ?>