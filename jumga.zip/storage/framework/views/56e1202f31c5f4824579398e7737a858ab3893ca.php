<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.dashboard') ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-5">

    <?php if($logged_in_user->hasApprovedShop()): ?>

            <div class="container">
                <div class="row">

                    <!-- Left Panel
                    ============================================= -->
                    <aside class="col-lg-3">

                        <!-- Profile Details
                        =============================== -->
                        <div class="bg-light shadow-sm rounded text-center p-3 mb-4">

                            <p class="text-3 font-weight-500 mb-2">Hello, <?php echo e($logged_in_user->full_name); ?></p>
                            <p class="mb-2"><a href="<?php echo e(route('frontend.user.account')); ?>" class="text-5 text-light" data-toggle="tooltip" title="Edit Profile"><i class="fas fa-edit"></i></a></p>
                        </div>
                        <!-- Profile Details End -->

                        <!-- Available Balance
                        =============================== -->
                        <div class="bg-light shadow-sm rounded text-center p-3 mb-4">
                            <div class="text-17 text-light my-3"><i class="fas fa-wallet"></i></div>
                            <h3 class="text-9 font-weight-400">$0</h3>
                            <p class="mb-2 text-muted opacity-8">Total Sales</p>
                            <hr class="mx-n3">
                            <div class="d-flex"><a href="#" class="btn-link mr-auto">View Order History</a> <a href="#" class="btn-link ml-auto">Customers</a></div>
                        </div>
                        <!-- Available Balance End -->

                        <!-- Need Help?
                        =============================== -->
                        <div class="bg-light shadow-sm rounded text-center p-3 mb-4">
                            <div class="text-17 text-light my-3"><i class="fas fa-comments"></i></div>
                            <h3 class="text-3 font-weight-400 my-4">Need Help?</h3>
                            <p class="text-muted opacity-8 mb-4">Have questions or concerns regarding your account?<br>
                                Our experts are here to help!.</p>
                            <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-primary btn-block">Chat with Us</a> </div>
                        <!-- Need Help? End -->

                    </aside>
                    <!-- Left Panel End -->

                    <!-- Middle Panel
                    ============================================= -->
                    <div class="col-lg-9">

                        <div class="row">
                            <div class="col-md-4">
                                <div class="bg-light shadow-sm rounded p-4 mb-4 text-center">
                                    <h5>Pending Orders</h5>
                                    <h2><?php echo e($logged_in_user->shop()->numOrders()); ?></h2>
                                    <a href="<?php echo e(route('frontend.shop.orders')); ?>" class="btn btn-primary">View Orders</a>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="bg-light shadow-sm rounded p-4 mb-4 text-center">
                                    <h5>Products in Stock</h5>
                                    <h2><?php echo e($logged_in_user->shop()->numProducts()); ?></h2>
                                    <a href="<?php echo e(route('frontend.product.index')); ?>" class="btn btn-primary">View Products</a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="bg-light shadow-sm rounded p-4 mb-4 text-center">
                                    <h5>Store Visits Today</h5>
                                    <h2><?php echo e(rand(0, 300)); ?></h2>
                                    <a href="<?php echo e($_ENV['APP_URL']); ?>/shop/<?php echo e($logged_in_user->shop()->slug); ?>" class="btn btn-primary" target="_blank">View Shop</a>
                                </div>
                            </div>
                        </div>
                        <!-- Shop Details
                        ============================================= -->
                        <div class="bg-light shadow-sm rounded p-4 mb-4">
                            <h3 class="text-5 font-weight-400 mb-3">Shop Details <a href="#edit-personal-details" data-toggle="modal" class="float-right text-1 text-uppercase text-muted btn-link"><i class="fas fa-edit mr-1"></i>Edit</a></h3>
                            <div class="row">
                                <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Business Name</p>
                                <p class="col-sm-9"><?php echo e($logged_in_user->shop()->name); ?></p>
                            </div>
                            <div class="row">
                                <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Store URL</p>
                                <p class="col-sm-9"><?php echo e($_ENV['APP_URL']); ?>/<?php echo e($logged_in_user->shop()->slug); ?></p>
                            </div>
                            <div class="row">
                                <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Date of Application</p>
                                <p class="col-sm-9"><?php echo e($logged_in_user->shop()->created_at->toDateString()); ?></p>
                            </div>
                            <div class="row">
                                <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Description</p>
                                <p class="col-sm-9"><?php echo e($logged_in_user->shop()->description); ?></p>
                            </div>
                        </div>
                        <!-- Edit Details Modal
                        ================================== -->
                        <div id="edit-personal-details" class="modal fade " role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title font-weight-400">Personal Details</h5>
                                        <button type="button" class="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                                    </div>
                                    <div class="modal-body p-4">
                                        <form id="personaldetails" method="post">
                                            <div class="row">
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label for="firstName">First Name</label>
                                                        <input type="text" value="Smith" class="form-control" data-bv-field="firstName" id="firstName" required placeholder="First Name">
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label for="fullName">Last Name</label>
                                                        <input type="text" value="Rhodes" class="form-control" data-bv-field="fullName" id="fullName" required placeholder="Full Name">
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="birthDate">Date of Birth</label>
                                                        <div class="position-relative">
                                                            <input id="birthDate" value="12-09-1982" type="text" class="form-control" required placeholder="Date of Birth">
                                                            <span class="icon-inside"><i class="fas fa-calendar-alt"></i></span> </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <h3 class="text-5 font-weight-400 mt-3">Address</h3>
                                                    <hr>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="address">Address</label>
                                                        <input type="text" value="4th Floor, Plot No.22, Above Public Park" class="form-control" data-bv-field="address" id="address" required placeholder="Address 1">
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label for="city">City</label>
                                                        <input id="city" value="San Ditego" type="text" class="form-control" required placeholder="City">
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label for="input-zone">State</label>
                                                        <select class="custom-select" id="input-zone" name="zone_id">
                                                            <option value=""> --- Please Select --- </option>
                                                            <option value="3613">Alabama</option>
                                                            <option value="3614">Alaska</option>
                                                            <option value="3615">American Samoa</option>
                                                            <option value="3616">Arizona</option>
                                                            <option value="3617">Arkansas</option>
                                                            <option value="3618">Armed Forces Africa</option>
                                                            <option value="3619">Armed Forces Americas</option>
                                                            <option value="3620">Armed Forces Canada</option>
                                                            <option value="3621">Armed Forces Europe</option>
                                                            <option value="3622">Armed Forces Middle East</option>
                                                            <option value="3623">Armed Forces Pacific</option>
                                                            <option selected="selected" value="3624">California</option>
                                                            <option value="3625">Colorado</option>
                                                            <option value="3626">Connecticut</option>
                                                            <option value="3627">Delaware</option>
                                                            <option value="3628">District of Columbia</option>
                                                            <option value="3629">Federated States Of Micronesia</option>
                                                            <option value="3630">Florida</option>
                                                            <option value="3631">Georgia</option>
                                                            <option value="3632">Guam</option>
                                                            <option value="3633">Hawaii</option>
                                                            <option value="3634">Idaho</option>
                                                            <option value="3635">Illinois</option>
                                                            <option value="3636">Indiana</option>
                                                            <option value="3637">Iowa</option>
                                                            <option value="3638">Kansas</option>
                                                            <option value="3639">Kentucky</option>
                                                            <option value="3640">Louisiana</option>
                                                            <option value="3641">Maine</option>
                                                            <option value="3642">Marshall Islands</option>
                                                            <option value="3643">Maryland</option>
                                                            <option value="3644">Massachusetts</option>
                                                            <option value="3645">Michigan</option>
                                                            <option value="3646">Minnesota</option>
                                                            <option value="3647">Mississippi</option>
                                                            <option value="3648">Missouri</option>
                                                            <option value="3649">Montana</option>
                                                            <option value="3650">Nebraska</option>
                                                            <option value="3651">Nevada</option>
                                                            <option value="3652">New Hampshire</option>
                                                            <option value="3653">New Jersey</option>
                                                            <option value="3654">New Mexico</option>
                                                            <option value="3655">New York</option>
                                                            <option value="3656">North Carolina</option>
                                                            <option value="3657">North Dakota</option>
                                                            <option value="3658">Northern Mariana Islands</option>
                                                            <option value="3659">Ohio</option>
                                                            <option value="3660">Oklahoma</option>
                                                            <option value="3661">Oregon</option>
                                                            <option value="3662">Palau</option>
                                                            <option value="3663">Pennsylvania</option>
                                                            <option value="3664">Puerto Rico</option>
                                                            <option value="3665">Rhode Island</option>
                                                            <option value="3666">South Carolina</option>
                                                            <option value="3667">South Dakota</option>
                                                            <option value="3668">Tennessee</option>
                                                            <option value="3669">Texas</option>
                                                            <option value="3670">Utah</option>
                                                            <option value="3671">Vermont</option>
                                                            <option value="3672">Virgin Islands</option>
                                                            <option value="3673">Virginia</option>
                                                            <option value="3674">Washington</option>
                                                            <option value="3675">West Virginia</option>
                                                            <option value="3676">Wisconsin</option>
                                                            <option value="3677">Wyoming</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label for="zipCode">Zip Code</label>
                                                        <input id="zipCode" value="22434" type="text" class="form-control" required placeholder="City">
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label for="inputCountry">Country</label>
                                                        <select class="custom-select" id="inputCountry" name="country" required>
                                                            <?php echo $__env->make('includes.partials.countries-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary btn-block mt-2" type="submit">Save Changes</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Personal Details End -->

                        <!-- Account Settings
                        ============================================= -->
                        <div class="bg-light shadow-sm rounded p-4 mb-4">

                        </div>

                    </div>
                    <!-- Middle Panel End -->
                </div>
            </div>
    <?php elseif($logged_in_user->hasPendingApplication()): ?>


    <div class="row justify-content-center">
        <div class="col-md-6 mx-auto">
            <div class="bg-light shadow-sm rounded p-4 mb-4">
                <h3 class="text-5 font-weight-400 mb-3 text-center">Shop Application Details</h3>
                <div class="row">
                    <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Name</p>
                    <p class="col-sm-9"><?php echo e($logged_in_user->shop()->name); ?></p>
                </div>
                <div class="row">
                    <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Store URL</p>
                    <p class="col-sm-9"><?php echo e($_ENV['APP_URL']); ?>/<?php echo e($logged_in_user->shop()->slug); ?></p>
                </div>
                <div class="row">
                    <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Date of Application</p>
                    <p class="col-sm-9"><?php echo e($logged_in_user->shop()->created_at->toDateString()); ?></p>
                </div>
                <div class="row">
                    <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Description</p>
                    <p class="col-sm-9"><?php echo e($logged_in_user->shop()->description); ?></p>
                </div>
                <div class="row">
                    <p class="col-sm-9">Make a payment of <?php echo e($_ENV['SHOP_REG_AMOUNT']); ?> <?php echo e($_ENV['DEFAULT_CURRENCY']); ?> by clicking the button below so your shop can be approved</p>
                </div>
                <div class="row">
                    <p class="col-12">
                        <button type="button" class="btn btn-primary btn-block mt-4" data-toggle="modal" data-target="#modalDefault">Proceed To Payment</button>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php else: ?>
        
                <h2 class="font-weight-400 text-center mt-3 mb-4">Create a Store</h2>
                <div class="row">
                    <div class="col-md-8 col-lg-6 col-xl-5 mx-auto">
                        <div class="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">
                            <h4 class="text-3 font-weight-400 mb-3">Let's get you started with your own online store for a small token.</h4>

                            <!-- Create Store Form
                            ============================================= -->
                            <form action="<?php echo e(route('frontend.shop.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="payerName">Store Name</label>
                                    <input type="text" value="" class="form-control" name="name" maxlength="191" required placeholder="Store Name">
                                </div>

                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea class="form-control" rows="4" id="description" name="description" required placeholder="Shop Description"></textarea>
                                </div>


                                <button class="btn btn-primary btn-block mt-4" id="submit-btn">Submit</button>
                            </form>
                            <!-- Create Store Form end -->
                        </div>
                    </div>
                </div>

    <?php endif; ?>

    </div>

    <?php if($logged_in_user->hasPendingApplication()): ?>

    <div class="modal fade" tabindex="-1" id="modalDefault">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <em class="icon ni ni-cross"></em>
                </a>
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Payment Details</h5>
                </div>
                <div class="modal-body">
                   <form action="<?php echo e(route('frontend.payment.start')); ?>" method="post">
                       <?php echo csrf_field(); ?>
                       <input type="hidden" name="payment_for" value="Shop">
                       <input type="hidden" name="item_id" value="<?php echo e($logged_in_user->shop()->id); ?>">
                       <div class="row">
                           <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Item Name:</p>
                           <p class="col-sm-9">Shop Approval</p>
                       </div>

                       <div class="row">
                           <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Qty</p>
                           <p class="col-sm-9">1</p>
                       </div>

                       <div class="row">
                           <p class="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Total Price</p>
                           <p class="col-sm-9"><?php echo e($_ENV['SHOP_REG_AMOUNT']); ?> <?php echo e($_ENV['DEFAULT_CURRENCY']); ?></p>
                       </div>

                       <div class="form-group">
                           <label for="first_name">First Name</label>
                           <input type="text" class="form-control" id="first_name" name="first_name" value="<?php if(isset($logged_in_user)): ?> <?php echo e($logged_in_user->first_name); ?> <?php endif; ?>">
                       </div>

                       <div class="form-group">
                           <label for="last_name">Last Name</label>
                           <input type="text" class="form-control" id="last_name" name="last_name" value="<?php if(isset($logged_in_user)): ?> <?php echo e($logged_in_user->last_name); ?> <?php endif; ?>">
                       </div>

                       <div class="form-group">
                           <label for="email">Email</label>
                           <input type="text" class="form-control" id="email" name="email" value="<?php if(isset($logged_in_user)): ?> <?php echo e($logged_in_user->email); ?> <?php endif; ?>">
                       </div>

                       <div class="form-group">
                           <label for="country">Country you're paying from</label>
                           <select id="country" class="form-control" name="country">
                               <?php echo $__env->make('includes.partials.countries-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           </select>
                       </div>

                       <button type="submit" class="btn btn-primary btn-block">Continue</button>
                   </form>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>

<?php $__env->stopPush(); ?>



<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/user/dashboard.blade.php ENDPATH**/ ?>