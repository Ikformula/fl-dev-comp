<!doctype html>
<html>
<head>
    <title>Make Payment</title>
</head>
<body>

<form>
    <script src="https://checkout.flutterwave.com/v3.js"></script>
    <button type="button" onClick="makePayment()">Pay Now</button>
</form>
<script>
    function makePayment() {
        FlutterwaveCheckout({
            public_key: "<?php echo e($_ENV['FLUTTERWAVE_PK']); ?>",
            tx_ref: "<?php echo e($payment->transaction_ref); ?>",
            amount: <?php echo e($payment->amount); ?>,
            currency: "<?php echo e($payment->currency); ?>",
            country: "<?php echo e($payment->country); ?>",
            payment_options: "card, mobilemoneyghana, ussd",
            redirect_url: // specified redirect URL
                "<?php echo e(route('frontend.verify.payment')); ?>?trx_ref=<?php echo e($payment->transaction_ref); ?>",
            meta: {
                consumer_mac: "<?php echo e(md5($payment->customer_email)); ?>",
            },
            customer: {
                email: "<?php echo e($payment->customer_email); ?>",
                name: "<?php echo e($payment->name); ?>",
            },
            callback: function (data) {
                console.log(data);
            },
            onclose: function () {
                // close modal
            },
            customizations: {
                title: "<?php echo e(app_name()); ?>",
                logo: "<?php echo e(asset('py/images/logo.png')); ?>",
            },
        });
    }

        makePayment();

</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/frontend/make-payment.blade.php ENDPATH**/ ?>