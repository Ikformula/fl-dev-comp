<aside class="aside-menu">

</aside>
<?php /**PATH C:\xampp\htdocs\jumga\resources\views/backend/includes/aside.blade.php ENDPATH**/ ?>