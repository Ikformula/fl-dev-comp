<?php

use App\Http\Controllers\Frontend\ContactController;
use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\User\AccountController;
use App\Http\Controllers\Frontend\User\DashboardController;
use App\Http\Controllers\Frontend\User\ProfileController;
use App\Http\Controllers\Frontend\Shop\ShopController;
use App\Http\Controllers\PaymentsController;
use App\Http\Controllers\ShopFrontController;

/*
 * Frontend Controllers
 * All route names are prefixed with 'frontend.'.
 */
Route::get('/', [HomeController::class, 'index'])->name('index');
Route::get('contact', [ContactController::class, 'index'])->name('contact');
Route::post('contact/send', [ContactController::class, 'send'])->name('contact.send');

//Payments
Route::post('start-payment', [PaymentsController::class, 'starter'])->name('payment.start');
Route::get('{trx_ref}/make-payment', [PaymentsController::class, 'makePayment'])->name('make.payment');
Route::get('verify-payment', [PaymentsController::class, 'verify'])->name('verify.payment');
Route::get('{trx_ref}/success', [PaymentsController::class, 'successNotice'])->name('payment.success.notice');


/*
 * These frontend controllers require the user to be logged in
 * All route names are prefixed with 'frontend.'
 * These routes can not be hit if the password is expired
 */
Route::group(['middleware' => ['auth', 'password_expires']], function () {
    Route::group(['namespace' => 'User', 'as' => 'user.'], function () {
        // User Dashboard Specific
        Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');

        // User Account Specific
        Route::get('account', [AccountController::class, 'index'])->name('account');

        // User Profile Specific
        Route::patch('profile/update', [ProfileController::class, 'update'])->name('profile.update');
    });
    Route::resource('shop', 'Shop\ShopController');
    Route::get('shop-orders', [ShopController::class, 'orders'])->name('shop.orders');
    Route::resource('product', 'Product\ProductController');

    // dispatch rider
    Route::get('assigned-shops', [DashboardController::class, 'dispatchStores'])->name('assigned.shops');
    Route::get('deliveries', [DashboardController::class, 'dispatchStoreDeliveries'])->name('deliveries');
});

// Public facing storefront routes
Route::get('store-front/{slug}', [ShopFrontController::class, 'products'])->name('shop_front.products');
Route::get('store-front/{slug}/{product_id}', [ShopFrontController::class, 'showProduct'])->name('shop_front.show.product');
Route::post('store-front/{slug}/{product_id}', [ShopFrontController::class, 'storeOrder'])->name('shop_front.store.order');
